﻿namespace slotikapi.Models;
using slotikapi.Models.Enums;

    public class Bookings
    {
        public int Id { get; set; }
        public DateTimeOffset StartsAt { get; set; }
        public DateTimeOffset EndsAt { get; set; }
        public BookingStatus Status { get; set; } = BookingStatus.Pending;
        public string? comment { get; set; }
        public  Boolean reminder_sent { get; set; }
        public List<Reviews>? reviews { get; set; }
        public Service service { get; set; } = null!;
        public  int service_id { get; set; }
        public Master master { get; set; } = null!;
        public  int master_id { get; set; }
        public User user { get; set; } = null!;
        public int user_id { get; set; }
    }

