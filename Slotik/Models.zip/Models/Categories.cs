﻿namespace slotikapi.Models
{
    public class Categories
    {
        public int Id { get; set; }
        public string name { get; set; } = String.Empty;
        public string icon { get; set; } = String.Empty;
    }
}
