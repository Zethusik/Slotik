﻿namespace slotikapi.Models
{
    public class Cities
    {
        public int Id { get; set; }
        public string name { get; set; } = String.Empty;
        public required List<Districts> districts { get; set; } = new List<Districts>();

    }
}
