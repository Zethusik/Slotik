﻿namespace slotikapi.Models
{
    public class Days_of
    {
        public int Id { get; set; }
        public DateOnly DateFrom { get; set; }
        public DateOnly DateTo { get; set; }

        public required Master master { get; set; } = null!;
        public int master_id { get; set; }
        


    }
}
