﻿namespace slotikapi.Models
{
    public class Districts
    {
        public int Id { get; set; }
        public  string name { get; set; } = String.Empty;
        public int CityId { get; set; }
        public Cities City { get; set; } = null!;
    }
}
