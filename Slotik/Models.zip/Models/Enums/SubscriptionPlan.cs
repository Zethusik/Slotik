﻿namespace slotikapi.Models.Enums;
public enum SubscriptionPlan
{
    Free,
    Basic,
    Pro
}

