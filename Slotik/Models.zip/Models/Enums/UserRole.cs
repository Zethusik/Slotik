﻿namespace slotikapi.Models.Enums;

public enum UserRole
{
    Client,
    Master,
    Superadmin
}
