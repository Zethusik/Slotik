﻿namespace slotikapi.Models
{
    public class Payments
    {
        public string Id { get; set; }
        public DateTimeOffset PaidAt { get; set; }
        public int SubscriptionId { get; set; }
        public Subscription Subscription { get; set; } = null!
        public required int amount { get; set; }
        public required Boolean status { get; set; }

        
    }
}
