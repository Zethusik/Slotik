﻿namespace slotikapi.Models
{
    public class Reviews
    {
        public int Id { get; set; }
        public int rating { get; set; } 
        public string text { get; set; } = string.Empty;
        public Bookings booking { get; set; } = null!;
        public  int booking_id { get; set; }
    }
}
