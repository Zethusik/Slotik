﻿namespace slotikapi.Models
{
    public class Schedules
    {
        public int Id { get; set; }
        public required int weekday { get; set; }
        public required DateTime start_time { get; set; }
        public required DateTime end_time { get; set; }
        public required DateTime break_start { get; set; }
        public required DateTime break_end { get; set; }
        public required Boolean is_working { get; set; }
        public Days_of? days_off { get; set; }
        public required Master master { get; set; } 
        public required int master_id { get; set; }
    }
}
