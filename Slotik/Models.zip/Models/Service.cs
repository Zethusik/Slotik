﻿using slotikapi.Models.Enums;
namespace slotikapi.Models;

public class Service
{
    public int Id { get; set; }
    public int MasterId { get; set; }

    public string Name { get; set; } = string.Empty;
    public int DurationMin { get; set; }
    public decimal Price { get; set; }
    public string? Description { get; set; }
    public string? Included { get; set; }
}