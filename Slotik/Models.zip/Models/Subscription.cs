﻿using slotikapi.Models.Enums;
namespace slotikapi.Models;


public class Subscription
{
    public int Id { get; set; }
    public int MasterId { get; set; }

    public SubscriptionPlan Plan { get; set; } = SubscriptionPlan.Free;
    public DateTime ExpiresAt { get; set; }
    public string Status { get; set; } = "active";
}